# Professor Paws · Canine Master Academy

A responsive personal study website with a dashboard, 20 courses A–T, three recovered lessons (A1, A2, J1.1), searchable outlines, autosaving lesson notes, topic-review tracking, written assignments, behavioural intake, progress export, and optional AI tutoring.

## Run
Requires Node.js 20 or later.
1. npm install
2. npm run check
3. npm start
Open http://localhost:3000.

## Publish on Render
Upload the contents of this folder to the root of your GitHub repository. Keep package.json, server.js, render.yaml and the public folder at the repository root.

In Render create a Web Service from the repository:
- Runtime: Node
- Build command: npm install
- Start command: npm start
- Health check: /health

AI tutoring is optional. Set OPENAI_API_KEY as a secret in Render to enable it. Never put the key in GitHub or browser files. Without a key the intake, lessons, notes and progress still work. This version is intended for personal use; add access controls and usage limits before offering API-funded tutoring to public visitors.

## Your curriculum
The original 12-department starter outline and sample quiz have been replaced with Canine Master Academy courses A–T from your earlier chats. Three existing lessons and their assignments are included, not newly invented replacements. Course O is partially recovered; P–T use the available earlier roadmap summaries. The later three-year plan is a provisional framework. Historical assessment thresholds vary, so written responses require instructor review. Practical competence is separate.

## Progress and privacy
Records and notes stay in the current browser. They do not sync across devices. Download progress to back it up. Updated curriculum storage is separate from the old MVP record; old records are not deleted. AI tutoring sends the entered conversation to OpenAI when configured. There is no account system, talking video avatar or automatic grading of written assignments.

## Verification
JavaScript syntax, five screen render paths, lesson controls, safe lesson text rendering, HTTP home/health responses and the missing-key tutoring response were checked. No Render deployment has been performed.
